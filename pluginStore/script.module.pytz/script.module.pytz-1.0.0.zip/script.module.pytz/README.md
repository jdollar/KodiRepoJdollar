script.module.pytz
======================

Python pytz library packed for Kodi.

See https://github.com/newvem/pytz.git

