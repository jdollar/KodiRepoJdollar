'''tzinfo timezone information for UTC.'''
from pytz import UTC
