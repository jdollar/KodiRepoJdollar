from lib.kissanime.kissanime import KissAnime

kissanime = KissAnime()
kissanime.run()
