import sys
import urllib2
import xbmcplugin
import xbmcgui
import js2py
import cfscraper

from bs4 import BeautifulSoup
from t0mm0.common.net import Net

ADDON_HANDLE = int(sys.argv[1])
KISS_ANIME_BASE_URL = 'http://kissanime.ru/'
ANIME_LIST_ENDPOINT = 'AnimeList'

class KissAnime:
    def __init__(self):
        xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    # End init

    def run(self):
        self.buildMainMenu()
    # End run

    def buildMainMenu(self):
        # net = Net(cloudflare=True)
        # response = net.http_GET(KISS_ANIME_BASE_URL + ANIME_LIST_ENDPOINT)
        # soup = BeautifulSoup(response.content,'html.parser')
        # print response.content
        # listingObj = soup.find('table', { "class": "listing" })
        # videoLinks = listingObj.find_all('a')
        # for videoLink in videoLinks:
        #    li = xbmcgui.ListItem(videoLink.renderContents(), iconImage='DefaultVideo.jpg')
        #    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=videoLink['href'], listitem=li, isFolder=True)
        li = xbmcgui.ListItem('Test', iconImage='DefaultVideo.jpg')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=None, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(ADDON_HANDLE)
    #End buildMainMenu
# End KissAnime
