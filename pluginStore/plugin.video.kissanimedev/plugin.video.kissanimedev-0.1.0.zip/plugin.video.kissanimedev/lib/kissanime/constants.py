KISS_ANIME_BASE_URL = 'http://kissanime.ru/'
ANIME_LIST_ENDPOINT = 'AnimeList'
CONTENT_TYPE_MOVIES = 'movies'

