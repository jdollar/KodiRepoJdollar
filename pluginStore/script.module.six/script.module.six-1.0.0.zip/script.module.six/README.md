script.module.six
======================

Python six library packed for Kodi.

See https://github.com/benjaminp/six
