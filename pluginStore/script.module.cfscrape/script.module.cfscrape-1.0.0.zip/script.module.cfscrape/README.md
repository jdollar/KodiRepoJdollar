script.module.cfscraper
======================

Python cfscraper library packed for Kodi.

See https://github.com/Anorov/cloudflare-scrape
